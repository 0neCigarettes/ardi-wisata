<aside id="sidebar" class="sidebar">
	<ul class="sidebar-nav" id="sidebar-nav">
		<li class="nav-item">
			<a class="nav-link " href="index.html">
				<i class="bi bi-cash-coin"></i>
				<span>Transaksi</span>
			</a>
		</li>
	</ul>
</aside>
