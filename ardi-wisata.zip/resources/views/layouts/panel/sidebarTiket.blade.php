<aside id="sidebar" class="sidebar">
	<ul class="sidebar-nav" id="sidebar-nav">
		<li class="nav-item">
			<a class="nav-link {{ route('tiketDashboard') === url()->current() ? '' : 'collapsed' }}" href="{{ route('tiketDashboard')}}">
				<i class="bi bi-grid"></i>
				<span>Tiket & Parkir</span>
			</a>
		</li>
	</ul>
</aside>
