<?php

namespace App\Http\Services;

class Service
{
}
